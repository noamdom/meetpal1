<?php
    require_once('../private/init.php');
    log_out();
    header("location: login.php");
    exit;


    