
<style>
    footer {
        position: fixed;
        left: 0;
        bottom: 0;
        height: 3%;
        width: 100%;
        background: #f9f7f7;
        color: white;
        text-align: center;
        border: 4px solid #EDE4E4;
    }
</style>
<footer>
        </footer>
        
    </body>
    
</html>


<?php db_disconnect($db);