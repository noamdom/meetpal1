-- MySQL dump 10.13  Distrib 5.6.45, for Linux (x86_64)
--
-- Host: localhost    Database: meetpalu_meetDB
-- ------------------------------------------------------
-- Server version	5.6.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Events`
--

DROP TABLE IF EXISTS `Events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `date` datetime NOT NULL,
  `location` varchar(64) NOT NULL,
  `shour` varchar(5) NOT NULL,
  `duration` float NOT NULL,
  `hostID` int(11) NOT NULL,
  `category` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Events`
--

LOCK TABLES `Events` WRITE;
/*!40000 ALTER TABLE `Events` DISABLE KEYS */;
INSERT INTO `Events` (`id`, `name`, `description`, `date`, `location`, `shour`, `duration`, `hostID`, `category`) VALUES (35,'','','0000-00-00 00:00:00','','',0,21,''),(34,'icons8-filter-26.png','have fun','2019-01-02 00:00:00','????? ???','',0,16,'arts'),(33,'roni','????? ????? ??????!','2019-05-30 00:00:00','Jerusalem','',0,16,'baking'),(32,'toni','saefjas','2019-07-31 00:00:00','tel aviv','',0,16,''),(31,'bbbb','great activity','2019-02-02 00:00:00','Jerusalem','',0,16,'design'),(30,'dinner','testy!','2020-03-02 00:00:00','king david st.','',0,15,'cooking'),(29,'partner for running','looking for a partner to run togehter all over the city !','2019-01-13 00:00:00','Jerusalem','',0,15,'run'),(27,'Acro in gan saker','we will meet in gan saker on saturdy like every week and practice together!','2016-05-21 00:00:00','Jerusalem','',0,16,'yoga'),(26,'bbbb','adsfsdf','2018-10-29 16:30:00','c1000','',0,10,'cooking'),(28,'Massage for free!','just finish massage course and want to practice ','2019-06-13 00:00:00','Tel Aviv','',0,16,'massage'),(23,'rock','gonnnae be fun','2019-05-14 20:00:00','tel-aviv','',0,10,'music'),(24,'Meditation Sitting','We will meet in my house and practice medidation for about an hour, a tea will be served after :)','2019-05-27 13:30:00','Jerusalem','',0,15,'meditation');
/*!40000 ALTER TABLE `Events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pword` varchar(50) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` (`id`, `username`, `email`, `pword`) VALUES (20,'shimonbe','shimon.ber@gmail.com','123'),(19,'shimon.ber','shimon.ber@gmail.com','123'),(18,'henofer','henofer1@gmail.com','123456'),(17,'alon','alon@aef','123'),(16,'noam','nnn@nnn','123'),(15,'avitalwerz','avitalwerz@gmail.com','123456'),(21,'','','');
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participants_groups`
--

DROP TABLE IF EXISTS `participants_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `participants_groups` (
  `helper_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`helper_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participants_groups`
--

LOCK TABLES `participants_groups` WRITE;
/*!40000 ALTER TABLE `participants_groups` DISABLE KEYS */;
INSERT INTO `participants_groups` (`helper_id`, `event_id`, `user_id`) VALUES (20,16,16),(19,16,16),(18,16,16),(17,0,16),(16,15,16),(15,15,17),(14,16,15),(13,16,15),(12,15,16),(11,15,16),(21,16,16),(22,15,16),(23,16,16),(24,15,16),(25,16,16),(26,15,16),(27,16,15),(28,16,13),(29,16,0),(30,16,0);
/*!40000 ALTER TABLE `participants_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_groups`
--

DROP TABLE IF EXISTS `provider_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provider_groups` (
  `helper_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`helper_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_groups`
--

LOCK TABLES `provider_groups` WRITE;
/*!40000 ALTER TABLE `provider_groups` DISABLE KEYS */;
INSERT INTO `provider_groups` (`helper_id`, `event_id`, `user_id`) VALUES (18,33,16),(17,32,16),(16,31,16),(15,30,15),(14,29,15),(13,28,16),(12,27,16),(11,24,15),(10,23,10),(19,34,16),(20,35,21);
/*!40000 ALTER TABLE `provider_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'meetpalu_meetDB'
--

--
-- Dumping routines for database 'meetpalu_meetDB'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-19  3:37:29
